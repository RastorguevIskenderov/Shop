﻿using ShoesShop.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ShoesShop.Pages
{
    /// <summary>
    /// Логика взаимодействия для AssortmentPage.xaml
    /// </summary>
    public partial class AssortmentPage : Page
    {
        public AssortmentPage()
        {
            InitializeComponent();
            AssortDGrid.ItemsSource = SneakerShopEntities.GetContext().Assortment.ToList();
        }

        private void AssortEditBtn_Click(object sender, RoutedEventArgs e)
        {
            ManagerIn.FrameIn.Navigate(new EditAssortmentPage((sender as Button).DataContext as Assortment));
        }

        private void AssortAddBtn_Click(object sender, RoutedEventArgs e)
        {
            ManagerIn.FrameIn.Navigate(new EditAssortmentPage(null));
        }
    }
}
