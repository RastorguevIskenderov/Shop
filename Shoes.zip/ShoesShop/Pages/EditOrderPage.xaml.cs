﻿using ShoesShop.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ShoesShop.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditOrderPage.xaml
    /// </summary>
    public partial class EditOrderPage : Page
    {
        private Orders _currentOrder = new Orders();
        public EditOrderPage(Orders selectedOrder)
        {
            InitializeComponent();

            if(selectedOrder != null)
            {
                _currentOrder = selectedOrder;
            }

            DataContext = _currentOrder;
            StatusCombo.ItemsSource = SneakerShopEntities.GetContext().Status.ToList();
            AssortmentCombo.ItemsSource = SneakerShopEntities.GetContext().Assortment.ToList();
            ClientCombo.ItemsSource = SneakerShopEntities.GetContext().Clients.ToList();
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {

            if(_currentOrder.Id == 0)
            {
                SneakerShopEntities.GetContext().Orders.Add(_currentOrder);
            }

            try
            {
                SneakerShopEntities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            ManagerIn.FrameIn.Navigate(new ChangeStatusPage());

            EditHistory editHistory = new EditHistory()
            {
                IdStuff = AppConnect.user.Id,
                Description = "Изменил/добавил заказ",
                EditDate = DateTime.Now,
            };
            SneakerShopEntities.GetContext().EditHistory.Add(editHistory);
            SneakerShopEntities.GetContext().SaveChanges();
        }
    }
}
